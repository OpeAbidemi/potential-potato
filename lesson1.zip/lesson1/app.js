// alert("Welcome to my webpage")
// prompt("Enter your firstname")
// confirm("Are you sure you want to exit")

// This is a single line comment
/* 
    This is a multiline comment
*/

// console.time("hello")

// // Writing to the document
// document.write("Hello World")
// // Changing the backgroundColor of the body
// document.body.style.backgroundColor = "crimson"
// // Changing the color of the body
// document.body.style.color = "white"
// // Logging the content of the body to the console
// console.log(document.body.innerHTML)

// console.timeEnd("hello")


document.getElementById("heading").innerHTML = "Hello James"
document.getElementById("heading").style.color = "white"

document.getElementsByClassName("box").item(0).style.backgroundColor = "goldenrod";
document.getElementsByClassName("box").item(0).style.fontSize = "50px";

document.getElementsByClassName("box").item(1).remove()
// document.getElementsByClassName("box").item(0).style.display = "none"
// document.getElementsByClassName("box").item(0).style.opacity = 0

// document.querySelector("*").style.color = "green"



