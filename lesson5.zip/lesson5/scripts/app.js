// console.log("Hey");

// let i = 6, j = 0;

// while (j < i) {
//     console.log(i);
//     i ++;
//     j += 2;
// }

// for(declaration ; condition ; ++\--)

for (let j = 0, i = 6;j < i; j+=2, i++) {
    console.log(j, i);
}





// j = j + 2;
/*
j = 0, i =6
j = 2, i =7
j =4, i =8;
j = 6, i =9;
j = 8, i = 10;
j= 10, i = 11,
j = 12, i = 12

*/
