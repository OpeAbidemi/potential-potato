// const names = ["James", "Harry", "Bond", "ade"];
// const scores = [20, 40, 50, 50];
// const matrix = [[0, 2, 5], [9, 6, 7], [9, 5, 3]];

// // console.log(names.length);
// // console.log(scores.length);
// // console.log(matrix.length);

// // names[1] = "Michael";

// // console.log(names[1]);

// // console.log(matrix[1][1] + matrix[2].length + scores[2] - matrix[2][0]);


// // const newLength  = names.push("Kiki", "John", "Peter");

// // console.log(newLength);

// // const removed = names.pop();

// // console.log(removed);

// // names.shift();

// // console.log(names);

// /**
//     push - add items at the end
//     pop - remove last item
//     shift - remove first item
//     unshift - add items in the front
//     slice

//  */

// // names.unshift("Kolade", "Tope")

// console.log(names.concat(scores));
// console.log(names);


const countries = ["Nigeria", "Ghana", "Togo", "Yemen", "Qatar", "USA", "Sweden" , "Finland", "Iceland", "Norway", "Argentina", "Brazil"]

// let i = 0;

// while (i < countries.length) {
//     if (countries[i] === "USA") {
//         i++; 
//         continue;
//     }
//     console.log(countries[i]);
//     i++;
// }

let i = 0

while (i < 10) {
    if (i % 2 === 0) {
        i++;
        break;
    }

    console.log(i);
    i++;
}

